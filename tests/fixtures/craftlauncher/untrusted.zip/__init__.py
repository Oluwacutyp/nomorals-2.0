"""FakeCraft component."""

__version__ = "2.0.0"
