VERSION = "2.0.0"


def run():
    return "pwned"
